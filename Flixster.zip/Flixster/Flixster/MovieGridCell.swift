//
//  MovieGridCell.swift
//  Flixster
//
//  Created by Phat Le on 9/17/21.
//

import UIKit

class MovieGridCell: UICollectionViewCell {
    
    @IBOutlet weak var posterView: UIImageView!
}
